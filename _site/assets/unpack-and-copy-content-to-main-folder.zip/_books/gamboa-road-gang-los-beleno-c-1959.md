---
title: "Gamboa road gang: (los forzados de Gamboa)"
key: "VHJI7BM2"
author: Beleño C., Joaquín
---
<div data-schema-version="8"><p>La carretera es el cementerio porque aun sus arenas están hechas de los huesos roídos por las olas de todos los peces que viajaron por las profundidades marinas y reposaron largo tiempo en el polvo calcáreo de la orilla.</p> <p>Para unos, la carretera es la civilización y el progreso, para mí es el sepulcro donde claudica para siempre el hambre voraz de toda esta fauna que sale de las montañas para enfrentarse a la civilización moderna. Es la culebra, de movimiento peristáltico y la colibrí de nervioso aletear. Es el hombre y el perro. Y si ello es así, ¿quién soy yo para desafiar con mis lentos movimientos el curso de los vehículos? ¿Quién soy yo para osar cruzar este sólido cementerio en donde todos los dpias mueren miles y miles de seres? Mueren tiernos celebrados por todos los gallotes que giran en el cielo.</p> </div>