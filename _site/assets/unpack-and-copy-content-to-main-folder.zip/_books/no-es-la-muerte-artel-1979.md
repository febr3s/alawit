---
title: "No es la muerte es el morir."
key: "PBZFBXDZ"
author: Artel, Jorge
---
<div data-schema-version="8"><p>Cerca de diez minutos estuvieron tableteando las metralletas. Por respuesta, silencio hostil en el monte. De modo repentino, una lluvia de valas desgajóse sobre los soldados, que se parapeteaban entre las peñas y algunos montículos. El contra-ataque fue tan sorpresivo que aquellos no tuvieron tiempo de dar cara al asalto. En el arroyo parece haber quedado toda la sengre del mundo.</p> <p>- Bueno, muchachos, escúllquenlos, recojan las armas y vámonos. ¡Rápido!</p> <p>Con sumetralleta aún caliente, el hombre joven que hubo dado la orden pasó un vistazo frío sobre el pelotón de muertos.</p> </div>