---
title: "La sombra: la novela de Ansina"
key: "WNVSZH8W"
author: Chagas, Jorge
---
<div data-schema-version="8"><p>¿Qué dirán de mí, cuando ya no esté, cuando mis huesos se hayan vuelto polvo?</p> <p>¿Qué crímenes y atropellos me achacarán?</p> <p>¿Cómo seré recordado?</p> <p>Esclavo retobado y desagradecido que no respetó a sus amos, un mal nacido, hombre de las más oscura condición y clase baja, secuaz de un caudillo tiránico y sanguinario, renegado, traidor a la Corona, blasfemo, hereje, canalla, criminal que cometió actos abominables en nombre de la revolución federal, siervo del llamado Atila de las Provincias Unidas que fue obsecuente con él hasta el infortunio, chúcaro, fornicador de yeguas, acaso sodomita. sacrílego, vil, disoluto, renegado, apátrida, desgraciado, bufo, salvaje, vulgar, infame que no respetó la autoridad ni el orden establecido, ¡un tupamaro! o tal vez, simplemente, el Negro Ansina, sin rostro y sin voz</p> </div>