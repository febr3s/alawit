---
title: "Malungos e milongas: (conto)"
key: "LNQGG366"
author: Ribeiro, Esmeralda
---
<div data-schema-version="8"><p>Dona Irina, a faxineira da empresa, dava consultas espirituais para Ruth, de quinze em quinze dias à hora do almoço.</p> <p>A faxineira colocava um avental vermelho-sangue, trinta pulseiras--- quinze em cada braço --- e um anel de ouro maciço, para receber o espírito de cigana Ina. Sentava de costas para a porta de entrada e Ruth fiçava A sua frente. Davam-se as mãos, uma olhando para a outra. A mulher mexia com a boca, sem emitir nehum som. Isto levava um bom tempo até a consulta.</p> <p>--- Filha, o que você quer da cigana Ina?</p> </div>