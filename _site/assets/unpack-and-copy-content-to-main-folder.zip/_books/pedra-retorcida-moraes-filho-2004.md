---
title: "Pedra retorcida"
author: Moraes Filho, João de
---
<div data-schema-version="8"><p>Repare</p> <p>Onde eu sou</p> <p>descansa um silêncio,</p> <p>e um moço fazendo círculos com pedras</p> <p>na beira do rio.</p> </div>