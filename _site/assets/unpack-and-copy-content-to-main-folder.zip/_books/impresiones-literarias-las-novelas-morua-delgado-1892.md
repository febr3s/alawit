---
title: "Impresiones literarias: Las novelas del sr. Villaverde"
key: "WKH7326M"
author: Morúa Delgado, Martín
---
<div data-schema-version="8"><p>_Madama Bovary_, en su fototipia social, y _La Tentasión_ de Sainte Antoine, en su universalismo, son ambas eminentemente psicológicas, y en particular la última de estas obras, que es además como el proceso artístico-filosólico de todos los sistemas de relijión y de moral de la humanidad en todas sus distintas manifestaciones. Diríase que Salambú es el punto de apoyo del egrejio maestro para alcanzar holgadamente á delinear en La Tentation de Sainte Antoine la sublime trajedia de la mente humana que resulta de ese superior esfuerzo intelectual. M. Flaubert no comprendía el arte sin la ciencia, y ésto constituye substancial y preferentemente la urdimbre de sus mejores obras.</p> </div>