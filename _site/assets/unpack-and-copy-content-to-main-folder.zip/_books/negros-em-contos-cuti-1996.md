---
title: "Negros em contos"
key: "4I4H4NGK"
author: «Cuti», Luiz Silva
---
<div data-schema-version="8"><p>Se o dia for bom, ainda sobrará para as balas e um maço de cigarros.</p> <p>Faz frio e a blusa que a mãe recebeu na casa da patroa não lhe aquece bem a magreza. No estômago, pão e café puros torcem-se.</p> <p>Força o calcanhar. O carrinho vai parando. A roda dianteira no ar, suspensa, gira livremente. Segue a Avenida Corifeu de Azevedo Marques,</p> <p>interrompida por escavações para saneamento básico. Entre buracos e montes esparsos de terra e asfalto destruído, empurra, sustentando as alças de madeira,</p> <p>que rolimãs sem asfalto não deslizam. Pés descalços, ele vai com a esperança de conseguir trabalho. Sente-se adulto aos 13 anos. Pensa na doença do irmão.</p> <p>Está resoluto: “Vou conseguir o remédio.”</p> </div>