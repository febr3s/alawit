---
title: "Ritmohéroe"
key: "NNJ6C6PK"
author: Bernard, Eulalia
---
<div data-schema-version="8"><p>El Carnaval,</p> <p>vamos, veamos los negros brincar,</p> <p>que trabajo no les vamos a dar.</p> <p></p> <p>El Carnaval,</p> <p>siéntete rey o reina del mar,</p> <p>negro!, es tu única oportunidad.</p> <p></p> <p>El Carnaval,</p> <p>Suda, embriaga, vomita tus penas,</p> <p>arrastra con ritmo tus cadenas,</p> <p>burla tres días de duras faenas.</p> <p></p> <p>El Carnaval</p> <p>desfigúrate, haz gozar,</p> <p>que en Semana Santa</p> <p>la cruz vas a llevar.</p> </div>