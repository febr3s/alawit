---
title: "Las estrellas son negras"
key: "A6UQJIRC"
author: Palacios, Arnoldo
---
<div data-schema-version="8"><p>Una gallina cacareó, removiéndose en su nido debajo del fogón. Irra se agachó, asomándose a observar detenidamente la gallina. Claro, una gallina gorda. ¿Por qué no matarla y comerla inmediatamente? Pero entonces no podrían vender el huevo que ponía diariamente. ¿El huevo de hoy? Irra se agachó más, estiró su cuerpo, templó el cuello, alargó el brazo para agarrar la gallina; esta se sacudió, arrinconándose más. Irra le lanzó otro zarpazo, deseando estrujarle de una vez la cabeza o rasgarle el vientre con las uñas. La gallina, asustadiza, saltó de su nido, alejándose bajo su plumaje blanquinegro-amarillento-cenizo. Resolvió dejar en paz a la gallina y se puso de pie. Tenía la mirada sombría, rucia la tez morena, el ánimo decaído; su estómago chirriaba vacío.</p> </div>