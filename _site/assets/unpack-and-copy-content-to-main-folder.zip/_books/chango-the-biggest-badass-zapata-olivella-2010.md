---
title: "Changó, the Biggest Badass"
key: "7CAPUDPI"
author: Zapata Olivella, Manuel; Tittler, Jonathan
---
<div data-schema-version="8"><p>Climb aboard this novel like so many million African prisoners on the slave ships; and feel free despite your chains.</p> <p>Take off your clothes!</p> <p>Whatever your race, culture, or class, don’t forget that the land where you tread is America, the New World, humanity’s new dawn. So become a child. If you find strange spirits ---in word, character, or plot---take them as a challenge to your imagination. Forget about academics, verb tenses, the boundaries between life and death, because in this saga there is no other trace than the one you leave behind: you are the prisoner, the discoverer, the founder, the liberator. </p> </div>