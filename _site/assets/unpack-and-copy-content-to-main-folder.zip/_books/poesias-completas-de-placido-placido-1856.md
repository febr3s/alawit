---
title: "Poesías completas de Plácido (Gabriel de la Concepción Valdés)."
key: "LYME9KVA"
author: «Plácido», Gabriel de la Concepción Valdés
---
<div data-schema-version="8"><p>Negra deidad que sin clemencia alguna</p> <p>De espinas al nacer me circuiste,</p> <p> Cual fuente clara cuya márgen viste</p> <p> Maguey silvestre y punzadora tuna; </p> <p>Entre el materno tálamo y la cuna</p> <p>El férreo muro del honor pusiste; </p> <p>Y acaso hasta las nubes me subiste, </p> <p>Por verme descender desde la luna.</p> </div>