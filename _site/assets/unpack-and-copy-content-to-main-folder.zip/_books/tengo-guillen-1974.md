---
title: "Tengo"
key: "8V8VIBDX"
author: Guillén, Nicolás; Carr, Richard J.
---
<div data-schema-version="8"><p>I have, just wait and see,</p> <p>that being black and all</p> <p>no one stopping me</p> <p>as bar or dance hall guest</p> <p>or treading the carpet of a hotel,</p> <p>shouting that there's no bed,</p> <p>no minimal cell and no colossal cell,</p> <p>no little cell where I might take my rest.</p> <p></p> <p>I have, just wait and see,</p> <p>freedom from the rural overseer</p> <p>who straps me up and puts me in a jail</p> <p>or drags my body from its native shed</p> <p>down the royal highway's helpless trail.</p> <p></p> <p>I have the land as well as I've the sea,</p> <p>no country,</p> <p>no high-life,</p> <p>no tennis and no yacht,</p> <p>but beach to endless waves and waves to beach,</p> <p>blue and naked giant of democracy:</p> <p>in short, the sea.</p> </div>