---
title: "El espejo y la ventana"
author: Ortiz, Adalberto
---
<div data-schema-version="8"><p>No comprende nada, no oye nada, pero la marea sube y sube atraída por el gastado plenilunio; hasta el día fatal en que, milagrosamente, se rompan todos los diques hacia el sol. Y, en definitiva, no es más que una pesada broma que le gastan a uno, con esto de traerlo a la vida manipulada por hilos inconsútiles.</p> <p>No ver, no ir. Testigo ciego y mudo de una era de silencios y omisiones, solamente en nuestra</p> </div>