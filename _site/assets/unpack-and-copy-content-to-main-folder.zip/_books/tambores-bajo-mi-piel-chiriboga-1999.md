---
title: "Tambores bajo mi piel"
key: "3MUBBFWP"
author: Chiriboga, Luz Argentina
---
<div data-schema-version="8"><p>Mi acento costeño atrajo la atención de mujeres, adormitadas en los asientos, que disimularon su curiosidad fingiendo arreglar algunos paquetes. A esa hora, todo, agotamiento general, convidaba al sueño. Al estar sola miedos imaginarios me llenaron la mente, por qué Dios había perdido, en ese instante, su poder creador de vida y movimiento. Volvió la voz de mamá con su Pórtate bien, que se transformó en dudas, sospechas, presagios y, más preciso, en temores. En la puerta de la agencia de transporte un hombre de blue jean esperaba la partida del bus que nos conduciría a Quito. Su gorra retuvo mis miradas, las botas lo evidenciaban llegado de lejos. Sin que pudiera verle el rostro se acercó al grabado de un paisaje andino adherido a la pared. Por el frío hundió las manos en los bolsillos de su chompa.</p> </div>