---
title: "Yania tierra: poema documento = document poem"
key: "3GVE3HJC"
author: Cartagena Portalatón, Aída; Fenwick, M. J.
---
<div data-schema-version="8"><p>CIERTO / Perdí el viejo juego de los versos</p> <p>Deseo conversar de otra manera</p> <p style="padding-left: 40px" data-indent="1">cuando la Zarza Ardiente</p> <p>Se quebranta bajo continuos aguaceros</p> <p>Con todo el dolor de una muerte</p> <p style="padding-left: 40px" data-indent="1">concebida</p> <p>Quién sería como Dios en la tierra</p> <p>Para soportar tanto silencio</p> <p>Si los testigos de estas letras nuevas</p> <p>Desean secuestrar la libertad de la palabra</p> <p style="padding-left: 40px" data-indent="1">Cotidiana</p> <p>Que traspasa tu cuerpo Yania Tierra</p> <p>***</p> <p>Traspasada / llegaría / llegó de repente</p> <p>La muerte desnuda / sin la ropa</p> <p>¡Qué noche calurosa!</p> </div>