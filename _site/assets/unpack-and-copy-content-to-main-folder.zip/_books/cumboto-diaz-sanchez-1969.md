---
title: "Cumboto"
key: "7VMJC5J4"
author: Díaz Sánchez, Ramón; Upton, John
---
<div data-schema-version="8"><p>I imagined thousands of fantastic things, and my nights were filled with erotic visions. There she was, not in the city but in the deep jungle, writing and gleaming at the center of a group of naked Negroes. She was dancing to the beat of the deep drums, whose music took on Beethoven’s rich harmony and yet retained all their telluric vigor. I knew that this was a strange and absurd synthesis, and yet in my dream I heard it happen. It was like a monstrous hybrid--of a dolphin or an albatross and a panther, say. It was so powerful that I was swept up in a kind of whirlwind, and I twisted and vibrated like a bow when its strings snaps. This was the goal toward which the uncontrollable, fiery cataract of my life was rushing. The dream reoccurred many times; it was the work of a clever succubus who came to my cot regularly to conduct her oneiric concert.</p> </div>