---
title: "Sofía; novela cubana."
author: Morúa Delgado, Martín
---
<div data-schema-version="8"><p>POBRE Sofía! Era una muchacha muy desgraciada. Cuando una vez, en los paseos que daba á la niña Julita, le interrogó una de sus compañeras, mujer de entrada edad, negra de respetable porte que solía decir que era el «jorcón de la casa», refiriéndose á la de sus señores, por los muchos años que llevaba en ella; viendo Sofía el cariñoso interés que le demostraba la buena mujer, contándole su historia le había dicho:</p> <p> </p> <p>—Yo no tengo padre ni madre. No los he conocido nunca. Yo no tengo familia.</p> </div>