---
title: "Tierra mojada"
key: "E63ACMZE"
author: Zapata Olivella, Manuel
---
<div data-schema-version="8"><p>—¿Y habrá tierra para mí?</p> <p>—Para todo el mundo. Esa vaina no tiene dueño —respondió López, con aire de magnanimidad—. Todo el que tenga valor para amarrarse los pantalones con las dificultades puede echar ancla. Es bueno que lo hagan ahora no más, para aprovechar las lluvias que ya se vienen.</p> <p>—Pues cuente conmigo. Dígame cuando se va para acompañarlo.</p> </div>