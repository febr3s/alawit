---
title: "The Devil's Nose"
key: "FD5E4XBF"
author: Chiriboga, Luz Argentina; Miller, Ingrid Watson; Morris, Margaret Lindsay
---
<div data-schema-version="8"><p>Kingston, September 8, 1900, <em>Saint Mary Day</em>.</p> <p>The news spreads rapidly in Jamaica. Representatives of the Guayaquil and Quito Railway Company are calling for laborers to go work in Ecuador, a country located in South America. Contractors MacDonald and H. Killan have gone to the harbor to offer such an important job opportunity to build the railway line. They promise good &nbsp;wages, proper treatment, and safety.</p> <p>Men approach in order to find out what is all about; nobody knows where Ecuador is. For the Marret brother Gregory and Syne, their mind is running while they consider what the contractors tell them and they beging to understand the proposal.</p> </div>