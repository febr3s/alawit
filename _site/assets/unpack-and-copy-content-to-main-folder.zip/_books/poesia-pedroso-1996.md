---
title: "Poesía"
key: "LMS3JB96"
author: Pedroso, Regino
---
<div data-schema-version="8"><p>Todos recordamos qué fuiste entre nosotros.</p> <p>Pero el patrón obeso que desangró tu vida</p> <p>en hemorragia de sudor,</p> <p>aún ignora que amaste, que sufriste y moriste;</p> <p>pues aunque todos somos máquinas de producción,</p> <p>él sólo ama las de acero,</p> <p>hechas en Chicago o en Glasgow.</p> <p></p> <p>Ahora ocupo tu puesto junto a la máquina:</p> <p>esmerilo las válvulas,</p> <p>reviso los pistones,</p> <p>como tú engraso el émbbolo, los vástagos, las bielas,</p> <p>y siempre atento al reloj,</p> <p>mi corazón frente a la vida</p> <p>se mecaniza igual que otro reloj.</p> </div>