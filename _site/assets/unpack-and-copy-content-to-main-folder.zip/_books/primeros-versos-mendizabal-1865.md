---
title: "Primeros versos"
key: "RAS6AX4R"
author: Mendizábal, Horacio
---
<div data-schema-version="8"><p>No pretendo, lector, que las pobres composiciones que te presento tengan algunas poesias; todo lo contrario, las juzgo solamente áridas y, quizá, imperfectas rimas; flores nacidas en frio y desolante páramo; tristes y raquíticas matas en medio del desierto—sin verdor, ni lozania—que carecen de la jentileza de la palma; pero que abundan en la monotonía de los estensos llanos.</p> <p>Así, lector, sé un tanto benigno al leer mis humildes versos. Hijos, algunos, del amor á la Patria y á la Libertad, otros lo son de mi pálida fantasia; quizá alguno fué inspirado por la virtud, quizá alguno por la melancolía. Mas en ninguna de mis composiciones encontrareis la fibra poética, el nervio natural de los sublimes soñadores; mi alma no se enciende en las llamas, do la quisiese ver fulgurar; no tengo una harpa.... carezco de una lira.</p> </div>