---
title: "Matalaché"
key: "ML4H3QAJ"
author: López Albújar, Enrique
---
<div data-schema-version="8"><p>Y en este vértigo del trabajo el negro era el que más contribuía con su sangre y su sudor. Al igual que las bestias, se le daba ración contada y medida. Al levantarse, el culén o la yerba luisa y un bollo de pan, elaborado por el mismo esclavo, o traído de alguna tahona miserable. Al mediodía, caldo gordo o sopa boba y un mate de zarandajas con arroz quebrado y ripioso. Así también en la merienda. Apenas si uno que otro día de la semana le caía entre las manos los restos malogrados de algún camarico, o una lonja de tasajo, o una paila de arroz con dulce, o un tinajón de champús, o una cabeza de plátanos verdes para asar, dado todo con alarde de liberalidad por algún patrón de conciencia más o menos católica.</p> </div>