---
title: "Cancion negra sin color."
key: "435CQ6VN"
author: Arozarena, Marcelino
---
<div data-schema-version="8"><p>El fandango</p> <p>de gran rango,</p> <p>que anda en grillo</p> <p>por el trillo tartamudo de vegetal castañuela</p> <p>--eco en fleco;</p> <p> &nbsp; cruz y espuela--</p> <p>es la rumba rimbombante que brina con desespero</p> <p>en los ceros majaderos del bongo.</p> <p></p> <p>Pacatá.</p> <p>Tacatá.</p> <p>Pacatacatacatá.</p> <p>¡Olé! ¡Alsá!</p> </div>