---
title: "Historia de un joven negro novela"
key: "5ZKYVD85"
author: Zapata Olivella, Juan
---
<div data-schema-version="8"><p>Era lunes, y el capitán mortificado por el calor sofocante, se quejó de los apagones de energía eléctrica que mantenían sin servicio el aparato de aire acondicionado. La secretaria, joven y pelirroja, le recordó los compromisos del día: visitar el club de oficiales; acudir a la cita del comisariato de compras, almorzar en el casino militar y revisar con sumo cuidado el expediente del bachiller negro.</p> </div>