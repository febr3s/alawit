---
title: "Memorial de Ayres"
key: "WFXITK8T"
author: Assis, Machado de
---
<div data-schema-version="8"><p>Nesse momento, a viuva descruzava as mãos, e fazia gesto de ir embora. Primeiramente espraiou os olhos, como a ver se estava só. Talvez quizesse beijar a sepultura, o proprio nome do marido, mas havia gente perto, sem contar dous coveiros que levavam um regador e uma enxada, e iam falando de um enterro daquella manhã. Falavam alto, e um escarnecia do outro, em voz grossa: «Eras capaz de levar um daquelles ao morro? Só se fossem quatro como tu.» Tratavam de caixão pezado, naturalmente, mas eu voltei depressa a atenção para a viuva, que se afastava e caminhava lentamente, sem mais olhar para traz. Encoberto por um mausoleu, não a pude ver mais nem melhor que a principio. Ella foi descendo até o portão, onde passava um bonde em que entrou e partiu. Nós descemos depois e viemos no outro.</p> </div>