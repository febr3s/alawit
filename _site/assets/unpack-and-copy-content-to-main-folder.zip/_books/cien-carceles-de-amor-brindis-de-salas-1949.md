---
title: "Cien cárceles de amor"
key: "BZSKI2E9"
author: Brindis de Salas, Virginia
---
<div data-schema-version="8"><p>Me cabe el cañaveral</p> <p>en cuatro dedos de ron.</p> <p>Poco paga el yanqui ya</p> <p>por este millón de canas</p> <p>que el negro sembró y corto.</p> <p>Mas no me trago este trago,</p> <p>porque es trago de sudor.</p> <p>Aquí el borracho es marino,</p> <p>pero si se pone a andar</p> <p>se ve que es de tierra el mar.</p> <p>La ola suelta de un trago</p> <p>aquí siempre es de huracán</p> </div>