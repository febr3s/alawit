---
title: "Autobiografía de un esclavo (moderniziada)"
key: "AFC996BH"
author: Manzano, Juan Francisco; Schulman, Iván A
---
<div data-schema-version="8"><p>Era un lugar tan soturno como apartado de la casa, en un traspetio junto a una caballeriza y junto a un apestoso y evaporante basurero, contiguo a un lugar común tan infestado como húmedo y siempre pestífero, separado de él sólo por unas paredes, todas agujereadas, guarida de deformes ratas que sin cesar me pasaban por encima. Yo que tenía la cabeza llena de cuentos de cosas malas de otros tiempos, de las almas aparecidas aquí de la otra vida, y de los encantamientos de los muertos, cuando salía un tropel de ratas haciendio ruido me parecía que estaba aquel sótano lleno de fantasmas.</p> </div>