---
layout: post
title: Tú no sabe inglé
guest: Osmar Romero
organization: El Marchante
tags: 
---

Our first program was dedicated to Nicolás Guillén. Chuby Cox visited us to talk about his translations of the Hispanic poet of negritude. He left us his playlist, his selection of Afro-Latin American works within and outside our archive, and several reflections on the challenges of translating poetics so grounded in music into a foreign language.

***

Nuestro primer programa estuvo dedicado a Nicolás Guillén. Nos visitó Chuby Cox para conversar sobre sus traducciones del poeta hispano de la negritud. Nos dejó su playlist, su selección de obras afrolatinoamericanas dentro y fuera de nuestro archivo y varias reflexiones sobre los retos de pasar una poética tan fundada en lo musical a una lengua extranjera.

