---
layout: busquedas
criterio: Date
title: año de edición
tagline: Books by year of edition
img: tema/edicion.jpg
---