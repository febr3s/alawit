---
title: Abraham Hall, Nancy
---