---
title: Delgado Mina, Sobeida
---