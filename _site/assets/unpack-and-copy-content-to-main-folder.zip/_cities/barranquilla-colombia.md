---
title: Barranquilla, Colombia
---